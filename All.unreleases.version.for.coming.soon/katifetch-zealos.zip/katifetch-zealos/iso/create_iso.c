#include <stdio.h>
#include "katifetch-zealos.iso.c"  // tu array de bytes

int main() {
    FILE *f = fopen("katifetch-zealos.iso", "wb");
    fwrite(katifetch_zealos_iso, 1, katifetch_zealos_iso_len, f);
    fclose(f);
    printf("ISO generado!\n");
    return 0;
}
